# Relativity Theory 2.0 – A Fractal Information-Based Model of Reality

**Author:** Karsten Lubig  
**Version:** April 2025  
**License:** CC BY-NC-ND 4.0 – Attribution, Non-Commercial, No Derivatives

---

## Overview

Relativity Theory 2.0 unifies General Relativity, quantum entanglement, information theory, and the concept of consciousness into a recursive model of reality.  
The universe is viewed as a structured information space, where energy and matter emerge from informational density, and where physical laws operate as rendered system parameters.  
The theory introduces a central equation integrating observation, entanglement, entropy, and awareness. It further explains cosmological anomalies such as dark matter, dark energy, and gravitational effects through system-based principles.  
Consciousness plays an active role, making the observer a part of the universal logic itself.

---

## Core Equation

```
R = (E_inf × ψ_entangled × ∇B) / (γ(O) × ΔS)
```

---

## Downloads

- `Relativitaetstheorie_2.0_Karsten_Lubig.pdf` (German original)

---

## License

This work is licensed under the Creative Commons CC BY-NC-ND 4.0 license.  
See [LICENSE](LICENSE.txt) for full terms.
